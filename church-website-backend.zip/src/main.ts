import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';

import { AppModule } from './app.module';
import { UsersSeed } from './users/users.seed';
import { ChurchInfoSeed } from './church-info/church-info.seed';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const usersSeed = app.get(UsersSeed);
  await usersSeed.run();

  const churchInfoSeed = app.get(ChurchInfoSeed);
  await churchInfoSeed.run();

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
    }),
  );

  await app.listen(process.env.PORT ?? 3000);
}

bootstrap();
