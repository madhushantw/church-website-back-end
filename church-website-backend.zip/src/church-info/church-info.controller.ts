import {
  Body,
  Controller,
  Get,
  Patch,
  UseGuards,
} from '@nestjs/common';

import { ChurchInfoService } from './church-info.service';
import { UpdateChurchInfoDto } from './dto/update-church-info.dto';

import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('church-info')
export class ChurchInfoController {
  constructor(private readonly churchInfoService: ChurchInfoService) {}

  @Get()
  findOne() {
    return this.churchInfoService.findOne();
  }

  @Patch()
  @UseGuards(JwtAuthGuard)
  update(@Body() data: UpdateChurchInfoDto) {
    return this.churchInfoService.update(data);
  }
}
